$(document).on("ready", function() {
    "use strict";

    $('.main-nav').scroller();

});