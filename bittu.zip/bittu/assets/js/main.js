(function ($) {
    "use strict";

    /*----------------------------
       		Preloader Active
       	------------------------------*/

    $(window).on('load', function () {
        $(".preloader").fadeOut(500);
    });

    /*----------------------------
       		Sticky Header Active
       	------------------------------*/

    $(window).on('scroll', function () {
        var scroll = $(window).scrollTop();
        if (scroll < 2) {
            $(".bittu-main-manu-content").removeClass("sticky");
        } else {
            $(".bittu-main-manu-content").addClass("sticky");
        }
    });

    /*----------------------------
        scrollIt Active
        ------------------------------*/
    $.scrollIt({
        upKey: 38, // key code to navigate to the next section
        downKey: 40, // key code to navigate to the previous section
        easing: "linear", // the easing function for animation
        scrollTime: 600, // how long (in ms) the animation takes
        activeClass: "active", // class given to the active nav element
        onPageChange: null, // function(pageIndex) that is called when page is changed
        topOffset: 0, // offste (in px) for fixed top navigation
    });
    /*----------------------------
        		services Active
        	------------------------------*/

    $(".bittu-all-services").owlCarousel({
        loop: true,
        autoplay: true,
        center: true,
        smartSpeed: 1000,
        dots: false,
        nav: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            992: {
                items: 3
            },
            1200: {
                items: 3
            }
        }
    });

    /*----------------------------
        		project Active
        	------------------------------*/

    $(".all-project-area").owlCarousel({
        loop: true,
        center: true,
        autoplay: true,
        smartSpeed: 1000,
        dots: true,
        nav: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            992: {
                items: 3
            },
            1200: {
                items: 3
            }
        }
    });

    /*---------------------
    	project active
    --------------------- */
    $('.project-views').magnificPopup({
        type: 'image'
    });

    /*----------------------------
        		team Active
        	------------------------------*/
    $('.all-team-area.owl-carousel').owlCarousel({
        items: 3,
        autoplay: true,
        smartSpeed: 1000,
        center: true,
        loop: true,
        dots: false,
        nav: true,
        navText: ["<i class='fa fa-angle-double-left '></i>", "<i class='fa fa-angle-double-right '></i>"],
        touchDrag: false,
        mouseDrag: false,
        responsive: {
            0: {
                items: 1
            },
            1030: {
                items: 2
            },
            1200: {
                items: 3
            }
        }
    });
    // Go to the next item
    var x = $('.all-team-area .owl-stage').children('.all-team-area .owl-item.active').eq(0);
    (x).addClass('bittu-show');
    $('.all-team-area .owl-next').click(function () {
        $('.all-team-area .owl-item.active.bittu-show').removeClass('bittu-show');
        var x = $('.all-team-area .owl-stage').children('.all-team-area .owl-item.active').eq(0);
        (x).addClass('bittu-show');
        console.log("Nextt");
    })
    // Go to the previous item
    $('.all-team-area .owl-prev').click(function () {
        $('.all-team-area .owl-item.active.bittu-show').removeClass('bittu-show');
        var x = $('.all-team-area .owl-stage').children('.all-team-area .owl-item.active').eq(0);
        (x).addClass('bittu-show');
        console.log("Prev");
    })

    /*---------------------
    	// popup2 active
    --------------------- */
    $('.portfolio-pop a').magnificPopup({
        type: 'image'
    });


    /*----------------------------
        		testimonial Active
        	------------------------------*/

    $(".all-testimonial-area").owlCarousel({
        loop: true,
        autoplay: true,
        smartSpeed: 1000,
        dots: true,
        nav: false,
        navText: ["<i class='fa fa-angle-left '></i>", "<i class='fa fa-angle-right '></i>"],
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            992: {
                items: 1
            },
            1200: {
                items: 1
            }
        }
    });

    /*----------------------------
        		Blog Slider Active
        	------------------------------*/

    $(".bittu-all-blog-list").owlCarousel({
        loop: true,
        autoplay: true,
        smartSpeed: 1000,
        dots: false,
        nav: false,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            992: {
                items: 3
            },
            1200: {
                items: 3
            }
        }
    });

    /*----------------------------
    		Video popup active
    	------------------------------*/

    $(".popup-video").magnificPopup({
        type: "iframe"
    });

    /*----------------------------
    		Counter Active
    	------------------------------*/

    $('.counter').counterUp({
        delay: 2,
        time: 1000
    });

    /*----------------------------
    		Magic Mouse Active
    	------------------------------*/
    magicMouse({
        "outerStyle": "circle",
        "hoverEffect": "circle-move",
        "hoverItemMove": false,
        "defaultCursor": false,
        "outerWidth": 30,
        "outerHeight": 30
    });

    /*----------------------------
    		button tilt Active
    	------------------------------*/
    $('.tilt').tilt({
        scale: 1.1,
    });

    /*----------------------------
        		AOS active
        	------------------------------*/

    AOS.init();

})(jQuery);